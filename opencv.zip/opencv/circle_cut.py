from PIL import Image, ImageDraw, ImageOps


# 새로운 이미지 생성
new_image = Image.new('RGBA', (400, 400), color=(0, 0, 0, 0))

# 중심 좌표 계산
center = (200, 200)

# 원 그리기
draw = ImageDraw.Draw(new_image)
draw.ellipse((center[0]-90, center[1]-90, center[0]+90, center[1]+90), fill=(0, 0, 0, 255))

# 이미지 자르기
cropped_image = ImageOps.crop(new_image, (0, 160, 0, 0))

# 새로운 이미지 생성
final_image = Image.new('RGBA', (400, 400), color=(0, 0, 0, 0))

# 이미지 붙이기
final_image.paste(cropped_image, (0, 160))

# 결과 출력
final_image.show()