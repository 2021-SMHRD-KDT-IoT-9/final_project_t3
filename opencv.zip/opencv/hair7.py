import cv2
import matplotlib.pyplot as plt

image_path = "./img/hairStyle_a000_2.jpg"
img1 = cv2.imread(image_path)

resized_img = cv2.resize(img1, (500, 600))

cv2.imwrite("resized_image.jpg", resized_img)

plt.imshow(cv2.cvtColor(resized_img, cv2.COLOR_BGR2RGB))
plt.show()