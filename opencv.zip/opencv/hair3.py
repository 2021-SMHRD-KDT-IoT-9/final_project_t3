import os
import numpy as np
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.preprocessing import image
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv2D, MaxPooling2D, Flatten, Dense
from tensorflow.keras.optimizers import Adam


# 데이터 경로 지정
train_dir = './img'

# 이미지 데이터 전처리
train_datagen = ImageDataGenerator(rescale=1./255, validation_split=0.2)

train_generator = train_datagen.flow_from_directory(
    train_dir,
    target_size=(400, 400),  # 이미지 크기를 400x400으로 변경
    batch_size=20,
    class_mode='categorical',
    subset='training',
    shuffle=True,  # 데이터 순서를 무작위로 섞음
)

validation_generator = train_datagen.flow_from_directory(
    train_dir,
    target_size=(400, 400),  # 이미지 크기를 400x400으로 변경
    batch_size=20,
    class_mode='categorical',
    subset='validation',
    shuffle=True  # 데이터 순서를 무작위로 섞음
)

# 모델 구축
model = Sequential([
    Conv2D(32, (3, 3), activation='relu', input_shape=(400, 400, 3)),  # 입력 형태를 400x400으로 변경
    MaxPooling2D(2, 2),
    Conv2D(64, (3, 3), activation='relu'),
    MaxPooling2D(2, 2),
    Conv2D(128, (3, 3), activation='relu'),
    MaxPooling2D(2, 2),
    Flatten(),
    Dense(512, activation='relu'),
    Dense(4, activation='softmax')
])

# 모델 컴파일
model.compile(optimizer=Adam(learning_rate=0.001), loss='categorical_crossentropy', metrics=['accuracy'], run_eagerly=True)

# 모델 학습
history = model.fit(
    train_generator,
    steps_per_epoch=train_generator.samples // train_generator.batch_size,
    epochs=30,
    validation_data=validation_generator,
    validation_steps=validation_generator.samples // validation_generator.batch_size
)

# 새로운 이미지 예측
def predict_image(file_path):
    img = image.load_img(file_path, target_size=(400, 400))
    x = image.img_to_array(img)
    x = np.expand_dims(x, axis=0) / 255
    prediction = model.predict(x)
    labels = list(train_generator.class_indices.keys())
    predicted_label = labels[np.argmax(prediction)]
    return predicted_label

# 예측 결과 출력
new_image_path = 'face3.png'
result = predict_image(new_image_path)
print(f"예측된 라벨: {result}")
