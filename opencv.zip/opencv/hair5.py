import os
import numpy as np
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.preprocessing import image
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv2D, MaxPooling2D, Flatten, Dense
from tensorflow.keras.optimizers import Adam


# 데이터 경로 지정
train_dir = './img'

# 이미지 데이터 전처리
train_datagen = ImageDataGenerator(rescale=1./255, validation_split=0.2)

train_generator = train_datagen.flow_from_directory(
    train_dir,
    target_size=(400, 400),  # 이미지 크기를 400x400으로 변경
    batch_size=20,
    class_mode='categorical',
    subset='training',
    shuffle=True,  # 데이터 순서를 무작위로 섞음
)

validation_generator = train_datagen.flow_from_directory(
    train_dir,
    target_size=(400, 400),  # 이미지 크기를 400x400으로 변경
    batch_size=20,
    class_mode='categorical',
    subset='validation',
    shuffle=True  # 데이터 순서를 무작위로 섞음
)

# 모델 구축
model = Sequential([
    Conv2D(32, (3, 3), activation='relu', input_shape=(400, 400, 3)),  # 입력 형태를 400x400으로 변경
    MaxPooling2D(2, 2),
    Conv2D(64, (3, 3), activation='relu'),
    MaxPooling2D(2, 2),
    Conv2D(128, (3, 3), activation='relu'),
    MaxPooling2D(2, 2),
    Flatten(),
    Dense(512, activation='relu'),
    Dense(4, activation='softmax')
])

# 모델 요약 정보 출력
model.summary()

# 모델 컴파일
model.compile(loss='categorical_crossentropy', optimizer=Adam(learning_rate=0.0001), metrics=['accuracy'], run_eagerly=True)

# 모델 학습
history = model.fit(
    train_generator,
    steps_per_epoch=train_generator.samples // train_generator.batch_size,
    epochs=30,
    validation_data=validation_generator,
    validation_steps=validation_generator.samples // validation_generator.batch_size
)

model.save('my_model.h5')


# 이미지 경로 설정
img_path = './face.png'

# 이미지 불러오기
img = image.load_img(img_path, target_size=(400, 400))

# 이미지 전처리
x = image.img_to_array(img)
x = np.expand_dims(x, axis=0)
x = x / 255.0

# 모델 예측
pred = model.predict(x)

# 예측 결과 출력
classes = train_generator.class_indices
for k, v in classes.items():
    if v == np.argmax(pred):
        print("이 이미지는 {} 클래스입니다.".format(k))