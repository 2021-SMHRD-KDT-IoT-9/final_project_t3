import cv2
import numpy as np
import matplotlib.pyplot as plt
from PIL import Image, ImageDraw, ImageOps

# 머리카락 이미지 경로
hair_image_path = "./img/hairStyle_a000_2.jpg"

# 합성할 원하는 이미지 경로
mannequin_image_path = "./img/mane2.jpg"

# 머리카락 이미지 읽기
hair_image = cv2.imread(hair_image_path)
hair_image = cv2.cvtColor(hair_image, cv2.COLOR_BGR2RGB)

# 합성할 원하는 이미지 읽기
mannequin_image = cv2.imread(mannequin_image_path)
mannequin_image = cv2.cvtColor(mannequin_image, cv2.COLOR_BGR2RGB)

# 머리카락 이미지 크기에 맞게 원하는 이미지 크기 조정
mannequin_resized = cv2.resize(mannequin_image, (hair_image.shape[1], hair_image.shape[0]))

# 머리카락 이미지를 위한 마스크 생성
mask = np.zeros_like(hair_image)
mask[np.where((hair_image > [0, 0, 0]).all(axis=2))] = [255, 255, 255]  # 머리카락 부분은 흰색으로 마스킹

# 마스크를 이용하여 머리카락 부분만 추출
hair_extracted = cv2.bitwise_and(hair_image, mask)

# 추출한 머리카락 이미지와 합성할 원하는 이미지 합성
result = cv2.bitwise_or(hair_extracted, mannequin_resized)

# 알파 채널 생성
alpha_channel = np.zeros((hair_image.shape[0], hair_image.shape[1]), dtype=np.uint8)
alpha_channel[np.where((hair_extracted > [0, 0, 0]).all(axis=2))] = 255  # 머리카락 부분은 완전히 불투명하게

# RGBA 이미지 생성
rgba_image = cv2.cvtColor(hair_extracted, cv2.COLOR_RGB2RGBA)
rgba_image[:, :, 3] = alpha_channel  # 알파 채널 설정

# RGBA이미지를 PIL이미지로 변환
pil_image = Image.fromarray(rgba_image)

# pil이미지를 RGBA모드로 변환
pil_image_rgba = pil_image.convert("RGBA")

# mannequin_resized를 PIL Image로 변환한 다음 RGBA 모드로 변환
mannequin_pil = Image.fromarray(mannequin_resized).convert("RGBA")

# 이미지 합성
composite_image = Image.alpha_composite(mannequin_pil, pil_image_rgba)

# composite_image를 다시 numpy 배열로 변환하는 작업을 의미합니다.
composite_array = np.array(composite_image)

# 흰색 픽셀을 검정색으로 변환할 범위를 정의
white_range = (composite_array >= [250, 250, 250, 255]).all(axis=2) & (composite_array <= [255, 255, 255, 255]).all(axis=2)

# 흰 픽셀을 검정색으로 변환
composite_array[white_range] = [0, 0, 0, 255]

# 합성된 이미지를 디스플레이에 출력
plt.imshow(composite_array)
plt.axis('off')
plt.show()

# 이미지 파일 경로
output_path = "./img/composite_image.jpg"

# BGR을 RGB로 저장
composite_array = cv2.cvtColor(composite_array, cv2.COLOR_BGR2RGB)

# composite_array 이미지 저장
cv2.imwrite(output_path, composite_array)