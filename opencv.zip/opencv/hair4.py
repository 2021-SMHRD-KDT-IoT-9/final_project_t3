import os
import numpy as np
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.preprocessing import image
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv2D, MaxPooling2D, Flatten, Dense
from tensorflow.keras.optimizers import Adam

# TensorFlow 버전 확인
print("TensorFlow version:", tf.__version__)

# Sequential 모델 생성
model = keras.models.Sequential()

# Conv2D 레이어 생성
conv_layer = keras.layers.Conv2D(32, (3,3), activation='relu', input_shape=(28,28,1))

# MaxPooling2D 레이어 생성
pool_layer = keras.layers.MaxPooling2D(pool_size=(2,2))

# Flatten 레이어 생성
flatten_layer = keras.layers.Flatten()

# Dense 레이어 생성
dense_layer = keras.layers.Dense(10, activation='softmax')

# 모델에 레이어 추가
model.add(conv_layer)
model.add(pool_layer)
model.add(flatten_layer)
model.add(dense_layer)

# 모델 요약 출력
model.summary()

# ImageDataGenerator 객체 생성
datagen = ImageDataGenerator()

# flow_from_directory 함수를 사용하여 이미지 데이터 생성
train_data = datagen.flow_from_directory(directory='./img', target_size=(224,224), batch_size=32, class_mode='binary')