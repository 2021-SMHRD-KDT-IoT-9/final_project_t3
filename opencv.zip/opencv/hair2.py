import cv2
import numpy as np
import matplotlib.pyplot as plt
from PIL import Image, ImageDraw, ImageOps

# 이미지 경로 지정
image_path = "./face2.png"

# 이미지 읽기
img = cv2.imread(image_path)

# 얼굴 검출
face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")
faces = face_cascade.detectMultiScale(img, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30))

# 얼굴 영역에서 +100px를 더한 좌표 추출
for (x, y, w, h) in faces:
    x -= 100
    y -= 100
    w += 200
    h += 200
    
    # 좌표값이 음수가 되지 않도록 조정
    x = max(0, x)
    y = max(0, y)

    # 얼굴 영역 추출
    face = img[y:y+h, x:x+w]

    # 헤어 부분의 색상 범위 지정 (검정색)
    lower = np.array([0, 0, 0], dtype=np.uint8)
    upper = np.array([120, 120, 120], dtype=np.uint8)

    # 색상 범위에 해당하는 부분 추출
    mask = cv2.inRange(face, lower, upper)
    hair = cv2.bitwise_and(face, face, mask=mask)

# 이미지 크기 조정
hair = cv2.resize(hair, (400, 400))

# 이미지 저장
cv2.imwrite("hair.jpg", hair)

# 결과를 출력
plt.imshow(cv2.cvtColor(hair, cv2.COLOR_BGR2RGB))
plt.show()

# 새로운 이미지 생성
image = Image.new('RGBA', (400, 400), color = (0, 0, 0, 0))

# 중심 좌표 계산
center = (200, 200)

# 원 그리기
draw = ImageDraw.Draw(image)
draw.ellipse((center[0]-90, center[1]-90, center[0]+90, center[1]+90), fill=(0,0,0,255))

# 이미지 저장
image.save('transparent_circle.png')

# 이미지 열기
background_image = Image.open('hair.jpg')

# 모드 변경
background_image = background_image.convert('RGBA')

overlay_image = Image.open('transparent_circle.png')

# overlay_image를 background_image에 합치기
background_image.alpha_composite(overlay_image)

# 합쳐진 이미지를 PNG 파일 형식으로 저장
background_image.save('combined_image.png')