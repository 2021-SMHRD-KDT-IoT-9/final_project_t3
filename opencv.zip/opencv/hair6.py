import numpy as np
from tensorflow.keras.preprocessing import image
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing.image import ImageDataGenerator
import tensorflow as tf


# 데이터 경로 지정
train_dir = './img'

# 이미지 데이터 전처리
train_datagen = ImageDataGenerator(rescale=1./255, validation_split=0.2)

train_generator = train_datagen.flow_from_directory(
    train_dir,
    target_size=(400, 400),  # 이미지 크기를 400x400으로 변경
    batch_size=20,
    class_mode='categorical',
    subset='training',
    shuffle=True,  # 데이터 순서를 무작위로 섞음
)

# 저장된 모델 불러오기
my_model = load_model('my_model.h5')

# 이미지 경로 지정
img_path = 'face2.png'

# 이미지 불러오기
img = image.load_img(img_path, target_size=(400, 400))

# 이미지를 numpy 배열로 변환
img_array = image.img_to_array(img)

# 이미지 배열을 확장하여 배치 형태로 변환
img_batch = np.expand_dims(img_array, axis=0)

# 모델을 사용하여 예측 수행
prediction = my_model.predict(img_batch)

# 클래스 인덱스 매핑
class_indices = train_generator.class_indices

# 예측 결과 출력
predicted_class = list(class_indices.keys())[list(class_indices.values()).index(np.argmax(prediction))]
print(predicted_class)