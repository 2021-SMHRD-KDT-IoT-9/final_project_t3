import React from 'react';
import { useLocation } from 'react-router-dom';

const YoutubePlay = () => {
  const location = useLocation();
  const videoSrc = location.state.videoSrc;

  console.log(videoSrc); // 콘솔에 videoSrc 값 출력

  return (
    <div>
      YoutubePlay
      <iframe width="448" height="252" src={videoSrc} title="YouTube video player" 
      frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
    </div>
  );
};

export default YoutubePlay;