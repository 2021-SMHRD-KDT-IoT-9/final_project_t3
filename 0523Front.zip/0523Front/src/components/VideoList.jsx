import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

const VideoList = () => {

  const [ckChange, setCkChange] = useState(true);
  const navigate = useNavigate()

  const handleRedirect = () => {
      setCkChange(false);
      navigate('/video-play');
    };

  return (
    <div>
      VideoList
      <br/>
      <button onClick={handleRedirect}>비디오 플레이어로 이동</button>
    </div>
  )
}

export default VideoList