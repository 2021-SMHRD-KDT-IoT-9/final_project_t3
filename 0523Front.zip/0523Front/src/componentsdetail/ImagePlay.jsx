import React from 'react';

const ImagePlay = () => {
  return (
    <div>ImagePlay
      <img src="/img/face2.png" alt="Face 2" style={{ width: "180px", height: "220px" }}></img>
    </div>
  );
};

export default ImagePlay;