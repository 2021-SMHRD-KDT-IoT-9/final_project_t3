import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const HairChoice = () => {

    const [ckChange, setCkChange] = useState(true);
    const navigate = useNavigate()

    const handleRedirect = () => {
        setCkChange(false);
        navigate('/change-api');
    };

    const handleRedirect2 = () => {
        setCkChange(false);
        navigate('/');
    };

    return (
        <div>HairChoice

            <button onClick={handleRedirect}>before</button>
            <button onClick={handleRedirect2}>After</button>

        </div>
    )
}

export default HairChoice