import React, { useState } from 'react';
import './App.css';
import { BrowserRouter, Routes, Route, Link} from 'react-router-dom';
import Youtube from './components/YoutubeList';
import MainPage from './components/MainPage';
import VideoList from './components/VideoList';
import ImageList from './components/ImageList';
import HairStyle from './components/HairStyle';
import YoutubePlay from './components/YoutubePlay';
import VideoPlay from './componentsdetail/VideoPlay';
import ImagePlay from './componentsdetail/ImagePlay';
import ChangeApi from './componentsdetail/ChangeApi';
import HairChoice from './componentsdetail/HairChoice';

function App() {
  const [isScaled, setIsScaled] = useState(false);

  const plus = () => {
    setIsScaled(true);
  };

  const minus = () => {
    setIsScaled(false);
  };

  const handleGoBack = () => {
    window.history.back(); // 브라우저의 뒤로가기 동작 실행
  };

  return (
    <BrowserRouter>
      <div>
        <div className="plus-btn">
          <button onClick={plus}>확대</button>
        </div>

        <div className="minus-btn">
          <button onClick={minus}>축소</button>
        </div>

        <div className={`main-containner ${isScaled ? 'scaled' : ''}`}>
          <Routes>
            <Route path="/" element={<MainPage />} />
            <Route path="/youtube" element={<Youtube />} />
            <Route path="/video-list" element={<VideoList />} />
            <Route path="/image-list" element={<ImageList />} />
            <Route path="/hair-style" element={<HairStyle />} />
            <Route path="/youtube-play" element={<YoutubePlay />} />
            <Route path="/video-play" element={<VideoPlay />} />
            <Route path='/image-play' element={<ImagePlay/>} />
            <Route path='/change-api' element={<ChangeApi/>} />
            <Route path='/hair-choice' element={<HairChoice/>}/>
          </Routes>
        </div>

        {!isScaled && (
          <div className={`menu-containner`}>
            <nav>
              <ul className="menu-list">
                <li>
                  <Link to="/">Main</Link>
                </li>
                <li>
                  <Link to="/youtube">Youtube</Link>
                </li>
                <li>
                  <Link to="/video-list">VideoList</Link>
                </li>
                <li>
                  <Link to="/image-list">ImageList</Link>
                </li>
                <li>
                  <Link to="/hair-choice">HairStyle</Link>
                </li>
                <li onClick={handleGoBack} className='go-back'>
                  뒤로가기
                </li>
              </ul>
            </nav>
          </div>
        )}
      </div>
    </BrowserRouter>
  );
}

export default App;