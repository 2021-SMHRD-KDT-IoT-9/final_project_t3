import React from 'react'

const SalonStyle = () => {
  return (
    <div className='salonstyle'>
      SalonStyle
    </div>
  )
}
export default SalonStyle