import React from 'react'

const MainPage = () => {
    
    return (
        <div>
            <img className="mainImg" src="/img/main.png" alt="Image" width="448" height="252"/>
        </div>
    )
}

export default MainPage