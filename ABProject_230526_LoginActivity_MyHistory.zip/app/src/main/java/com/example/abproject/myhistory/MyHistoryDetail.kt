package com.example.abproject.myhistory

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import com.example.abproject.R

class MyHistoryDetail : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_my_history_detail)

        val tvDate6 : TextView = findViewById(R.id.tvDate6)
        val tvShopName6 : TextView = findViewById(R.id.tvShopName6)
        val imgDetail : ImageView = findViewById(R.id.imgDetail)
        val etMyDetail : EditText = findViewById(R.id.etMyDetail)
        val btnRegist : Button = findViewById(R.id.btnRegist)
        val btnDelete : Button = findViewById(R.id.btnDelete)
        val imgback6 : ImageView = findViewById(R.id.imgback6)

        val imgId = intent.getIntExtra("imgId", 0)
        val date = intent.getStringExtra("tvDate5")
        val shopName = intent.getStringExtra("tvShopName5")

        imgDetail.setImageResource(imgId)
        tvDate6.text = date
        tvShopName6.text = shopName

        imgback6.setOnClickListener {
            val intent = Intent(this, MyHistory::class.java)
            startActivity(intent)
        }

    }
}