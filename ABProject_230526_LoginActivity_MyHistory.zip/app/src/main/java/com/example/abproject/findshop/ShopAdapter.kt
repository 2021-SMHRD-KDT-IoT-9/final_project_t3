package com.example.abproject.findshop

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.abproject.R

class ShopAdapter (context: Context, layout: Int, shopList: MutableList<ShopVO>)
    : RecyclerView.Adapter<ShopAdapter.ViewHolder>(){
    private val context = context
    private val layout = layout
    private val shopList = shopList
    private val inflater = LayoutInflater.from(context)

    class ViewHolder(view:View) :RecyclerView.ViewHolder(view){
        val imgShop : ImageView = view.findViewById(R.id.imgShop)
        val shopName : TextView = view.findViewById(R.id.shopName)
        val shopAddress : TextView = view.findViewById(R.id.shopAddress)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        var view = inflater.inflate(layout, parent, false)
        return ViewHolder(view)
    }

    override fun getItemCount(): Int {
        return shopList.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.imgShop.setImageResource(shopList[position].imgShop)
        holder.shopName.text = shopList[position].shopName
        holder.shopAddress.text = shopList[position].shopAddress

        holder.imgShop.setOnClickListener {
            val intent = Intent(context, DetailShop::class.java)
            intent.putExtra("imgId", shopList[position].imgShop)
            intent.putExtra("shopName", shopList[position].shopName)
            intent.putExtra("shopAddress", shopList[position].shopAddress)

            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
        }
    }


}