package com.example.abproject.findshop

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.abproject.MainActivity
import com.example.abproject.R

class FindShop : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_find_shop)

        val imgback: ImageView = findViewById(R.id.imgback)
        val rvShop : RecyclerView = findViewById(R.id.rvShop)

        imgback.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }

        val shopList = mutableListOf<ShopVO>()
        shopList.add(ShopVO(R.drawable.shop1, "젠코헤어혼 운암점", "운암동 228"))
        shopList.add(ShopVO(R.drawable.shop2, "쌤시크 광주점", "북구 69"))
        shopList.add(ShopVO(R.drawable.shop3, "연제살롱", "연제동 6-1"))
        shopList.add(ShopVO(R.drawable.shop4, "꽃피는봄미용실", "유촌동 865-10"))
        shopList.add(ShopVO(R.drawable.shop5, "살롱루디크", "신용동 858"))

        val adapter = ShopAdapter(this, R.layout.shop_list, shopList)

        rvShop.layoutManager = LinearLayoutManager(applicationContext,LinearLayoutManager.VERTICAL,false)
        rvShop.adapter = adapter


    }
}