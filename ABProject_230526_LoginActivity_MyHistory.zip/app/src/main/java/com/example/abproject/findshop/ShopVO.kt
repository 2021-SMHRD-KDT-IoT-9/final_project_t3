package com.example.abproject.findshop

data class ShopVO (
    var imgShop : Int = 0,
    var shopName: String = "",
    var shopAddress : String = ""
)