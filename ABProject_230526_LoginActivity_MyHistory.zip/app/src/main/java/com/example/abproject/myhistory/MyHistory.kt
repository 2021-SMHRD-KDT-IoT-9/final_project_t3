package com.example.abproject.myhistory

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.ImageView
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.abproject.MainActivity
import com.example.abproject.R

class MyHistory : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_my_history)

        val imgback5 : ImageView = findViewById(R.id.imgback5)
        val rvMy : RecyclerView = findViewById(R.id.rvMyList)

        for (vo in LoginCheck.SalList) {
            Log.d("mySal", vo.toString());
        }

        val myList = mutableListOf<MyVO>()

        for (vo in LoginCheck.SalList){
            myList.add(MyVO(vo.member_id,vo.cut_dy,vo.salon_name,vo.pic_path,vo.memo))
        }

        val adapter = MyAdapter(this, R.layout.my_list, myList)

        rvMy.layoutManager = LinearLayoutManager(applicationContext, LinearLayoutManager.VERTICAL, false)
        rvMy.adapter = adapter



        imgback5.setOnClickListener {
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
        }

    }
}