package com.example.abproject.myhistory

data class MyVO (
   val member_id : String = "",
   val cut_dy : String = "",
   val salon_name: String = "",
   val pic_path: String = "",
   val memo: String? = null
)
