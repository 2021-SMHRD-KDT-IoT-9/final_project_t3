package com.example.abproject

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import com.example.abproject.findshop.FindShop
import com.example.abproject.myhistory.LoginActivity
import com.example.abproject.myhistory.MyHistory

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btntest : Button = findViewById(R.id.btntest)
        val tvtest : TextView = findViewById(R.id.tvtest)
        val apiUrl = "http://your-api-url"


        val imgFindShop : ImageView = findViewById(R.id.imgFindShop)
        val imgMyHistory : ImageView = findViewById(R.id.imgMyHistory)

        imgFindShop.setOnClickListener {
            val intent = Intent(this, FindShop::class.java)
            startActivity(intent)
        }

        imgMyHistory.setOnClickListener {
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
        }

        btntest.setOnClickListener {
            tvtest.text = "Hi"
        }
        fun fetchDataFromSprint(){

        }
    }
}