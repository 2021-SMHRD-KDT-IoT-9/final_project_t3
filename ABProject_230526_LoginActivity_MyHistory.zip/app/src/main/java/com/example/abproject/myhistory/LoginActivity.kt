package com.example.abproject.myhistory

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import com.android.volley.Request
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.example.abproject.MainActivity
import com.example.abproject.R
import org.json.JSONArray
import java.nio.charset.Charset

class LoginActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        val etId : EditText = findViewById(R.id.etId)
        val btnLogin : Button = findViewById(R.id.btnLogin)
        val imgback : ImageView = findViewById(R.id.imgbackL)

        val queue = Volley.newRequestQueue(applicationContext)


        fun fetchStringDataFromSpring() {
                val reqId : String = etId.text.toString()
                val apiUrl = "http://59.0.234.211:8087/idconfig?id=$reqId"
                val request = StringRequest(
                    Request.Method.GET,
                    apiUrl,
                    { response ->
                        val decodedResponse = String(response.toByteArray(Charsets.ISO_8859_1), Charset.forName("UTF-8"))
                        val array = JSONArray(decodedResponse)
                        if (array.length() > 0){
                            Toast.makeText(this,"로그인 성공",
                                Toast.LENGTH_SHORT).show()

                            var memberId : String = ""

                            for (i in 0 until array.length()){
                                val result = array.getJSONObject(i)
                                memberId = result.getString("member_id")
                                val cutDy = result.getString("cut_dy")
                                val salonName = result.getString("salon_name")
                                val picPath = result.getString("pic_path")
                                val memo = result.getString("memo")

                                val test = MyVO(memberId,cutDy,salonName,picPath,memo)

                                LoginCheck.SalList.add(test)
                                Log.d("name123",salonName)

                                val myList = mutableListOf<MyVO>()
                                myList.add(MyVO(memberId,cutDy,salonName,picPath,memo))

                            }

                            if (memberId == etId.text.toString()) {
                                val intent = Intent(this, MyHistory::class.java)
                                startActivity(intent)
                                finish()
                            }
                        } else{
                            Toast.makeText(this, "로그인 실패", Toast.LENGTH_SHORT).show()
                        }
                    },
                    {
                        error ->
                        Toast.makeText(this,"연결실패",
                        Toast.LENGTH_SHORT).show()
                    }
                )
                request.setShouldCache(false)
                queue.add(request)
            }

        btnLogin.setOnClickListener {
            fetchStringDataFromSpring()
            LoginCheck.SalList.clear() // 기존 값 제거
        }

        imgback.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }
    }
}