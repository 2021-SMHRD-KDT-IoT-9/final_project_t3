package com.example.abproject.myhistory

class LoginCheck {

    companion object{
        var info : MyVO? = null
        var SalList : MutableList<MyVO> = mutableListOf<MyVO>()
    }

}