import React from 'react'

const SalonStyle = () => {
  return (
    <div>SalonStyle</div>
  )
}

export default SalonStyle