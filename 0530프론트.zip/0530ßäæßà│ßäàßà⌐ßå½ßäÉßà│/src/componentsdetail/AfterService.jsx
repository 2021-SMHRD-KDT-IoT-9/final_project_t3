import React from 'react'

const AfterService = () => {
    return (
        <div>AfterService
            <img
                src="http://172.30.1.91:5000/static/after.jpg?cache=false"
                alt="기본 이미지"
                style={{ width: "180px", height: "220px" }}
            />
        </div>
    )
}

export default AfterService