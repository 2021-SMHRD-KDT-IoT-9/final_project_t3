import React, { useRef, useState, useEffect } from "react";
import axios from "axios";
import { useNavigate } from 'react-router-dom';

function Change() {

    const navigate = useNavigate();
    const [convertedImage, setConvertedImage] = useState(null);

    const redirectSalonStyle=()=>{
        navigate('/salon-style');
    }

    const handleClick = (hairType) => {

        /*
        업로드 된 사진을 쓸 경우에는 첫 번째 axios를 지우고 이 부분을 넣으면 됨
        const formData = new FormData();
        formData.append("image_target", fileInputRef.current.files[0], "file");
        formData.append("hair_type", hairType);
        */

        axios
            .get("http://172.30.1.91:5000/static/before.jpg", { responseType: "blob" })
            .then((response) => {
                const file = new File([response.data], "face2.png", { type: "image/png" });
                const formData = new FormData();
                formData.append("image_target", file);
                formData.append("hair_type", hairType);

                axios
                    .post(
                        "https://www.ailabapi.com/api/portrait/effects/hairstyle-editor",
                        formData,
                        {
                            headers: {
                                "ailabapi-api-key":
                                    "Zk0JlRms4uOT5C6X2qBJcgvMmLWhOMGjNzH14gEeIVobfYKCQ8SFj57ydeQFY7Kn",
                                "Content-Type": "multipart/form-data",
                            },
                            timeout: 5000,
                        }
                    )
                    .then((response) => {
                        setConvertedImage("data:image/jpeg;base64," + response.data.data.image);
                    })
                    .catch((error) => {
                        alert("실패");
                    });
            })
            .catch((error) => {
                alert("이미지 가져오기 실패");
            });
    };

    return (
        <div style={{ display: "flex", flexDirection: "row", alignItems: "center" }}>
            <div>
                {convertedImage ? (
                    <img
                        src={convertedImage}
                        alt="변환된 이미지"
                        style={{ width: "180px", height: "220px" }}
                    />
                ) : (
                    <img
                        src="http://172.30.1.91:5000/static/before.jpg?cache=false"
                        alt="기본 이미지"
                        style={{ width: "220px", height: "180px" }}
                    />
                )}
            </div>

            <div style={{ marginLeft: "20px" }}>
                <button style={{ display: "block" }} onClick={() => handleClick(0)}>
                    앞머리
                </button>
                <button style={{ display: "block" }} onClick={() => handleClick(1)}>
                    긴머리
                </button>
                <button style={{ display: "block" }} onClick={() => handleClick(2)}>
                    긴머리+앞머리
                </button>
                <button style={{ display: "block" }} onClick={() => handleClick(3)}>
                    모발수증가
                </button>
                <button style={{ display: "block" }} onClick={() => handleClick(901)}>
                    스트레이트 헤어
                </button>
                <button style={{ display: "block" }} onClick={redirectSalonStyle}>
                    우리 미용실 헤어
                </button>
            </div>
        </div>
    );
}

export default Change;