import React, { useRef, useState, useEffect } from "react";
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

const VideoList = () => {
  const [data, setData] = useState([]);
  const [ckChange, setCkChange] = useState(true);
  const navigate = useNavigate()

  const handleRedirect = (video_id) => {
    setCkChange(false);
    console.log("video_id:", video_id);
    navigate(`/video-play?video_id=${video_id}`);
    // 작은따옴표가 아니라 ``(백틱임)
  };

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const response = await axios.get('http://59.0.234.211:8087/videolist');
      setData(response.data);
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };

  return (
    <div>
      VideoList
      <br />
      <ul>
        {data.map((video) => (
          <li onClick={() => handleRedirect(video.video_id)}>
            <div>NAME : {video.video_name}</div>
          </li>
        ))}
      </ul>
    </div>
  )
}

export default VideoList;
