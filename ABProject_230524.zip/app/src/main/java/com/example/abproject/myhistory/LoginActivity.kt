package com.example.abproject.myhistory

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import com.example.abproject.R

class LoginActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        val etId : EditText = findViewById(R.id.etId)
        val btnLogin : Button = findViewById(R.id.btnLogin)
        val imgback : ImageView = findViewById(R.id.imgbackL)

        btnLogin.setOnClickListener {
            if(etId.text.toString().equals("smhrd")){
                Toast.makeText(this, "로그인 성공",
                Toast.LENGTH_SHORT).show()
            }else{
                Toast.makeText(this, "로그인 실패",
                Toast.LENGTH_SHORT).show()
            }
        }
    }
}