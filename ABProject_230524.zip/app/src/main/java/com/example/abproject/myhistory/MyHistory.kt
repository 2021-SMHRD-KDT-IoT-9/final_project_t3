package com.example.abproject.myhistory

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.abproject.MainActivity
import com.example.abproject.R

class MyHistory : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_my_history)

        val imgback5 : ImageView = findViewById(R.id.imgback5)
        val rvMy : RecyclerView = findViewById(R.id.rvMyList)

        imgback5.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }

        val myList = mutableListOf<MyVO>()
        myList.add(MyVO(R.drawable.img1, "2023년 2월 5일(화)", "금남로 미용실"))
        myList.add(MyVO(R.drawable.img2, "2023년 4월 10일(일)", "남구 미용실"))
        myList.add(MyVO(R.drawable.img3, "2023년 5월 1일(토)", "동구 미용실"))
        myList.add(MyVO(R.drawable.img4, "2023년 6월 14일(수)", "광주 미용실"))

        val adapter = MyAdapter(this, R.layout.my_list, myList)

        rvMy.layoutManager = LinearLayoutManager(applicationContext, LinearLayoutManager.VERTICAL, false)
        rvMy.adapter = adapter
    }
}