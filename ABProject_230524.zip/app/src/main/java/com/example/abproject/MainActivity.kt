package com.example.abproject

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import com.example.abproject.findshop.FindShop
import com.example.abproject.myhistory.LoginActivity
import com.example.abproject.myhistory.MyHistory

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val imgFindShop : ImageView = findViewById(R.id.imgFindShop)
        val imgMyHistory : ImageView = findViewById(R.id.imgMyHistory)

        imgFindShop.setOnClickListener {
            val intent = Intent(this, FindShop::class.java)
            startActivity(intent)
        }

        imgMyHistory.setOnClickListener {
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
        }
    }
}