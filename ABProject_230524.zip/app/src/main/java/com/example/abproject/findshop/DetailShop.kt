package com.example.abproject.findshop

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import com.example.abproject.R

class DetailShop : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail_shop)

        val img3 : ImageView = findViewById(R.id.img3)
        val tvShopName : TextView = findViewById(R.id.tvShopName)
        val tvAdd : TextView = findViewById(R.id.tvAdd)
        val imgback2 : ImageView = findViewById(R.id.imgback2)

        val imgId = intent.getIntExtra("imgId", 0)
        val shopName = intent.getStringExtra("shopName")
        val shopAddress = intent.getStringExtra("shopAddress")

        img3.setImageResource(imgId)
        tvShopName.text = shopName
        tvAdd.text = shopAddress

        imgback2.setOnClickListener {
            val intent = Intent(this, FindShop::class.java)
            startActivity(intent)
        }

    }
}