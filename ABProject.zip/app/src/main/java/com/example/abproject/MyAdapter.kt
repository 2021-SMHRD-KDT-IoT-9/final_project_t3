package com.example.abproject

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class MyAdapter (context:Context, layout:Int, myList: MutableList<MyVO>)
    : RecyclerView.Adapter<MyAdapter.ViewHolder>(){
    private val context = context
    private val layout = layout
    private val myList = myList
    private val inflater = LayoutInflater.from(context)

    class ViewHolder(view:View) : RecyclerView.ViewHolder(view){
        val img5 : ImageView = view.findViewById(R.id.img5)
        val tvDate5 : TextView = view.findViewById(R.id.tvDate5)
        val tvShopName5 : TextView = view.findViewById(R.id.tvShopName5)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        var view = inflater.inflate(layout, parent, false)
        return ViewHolder(view)
    }

    override fun getItemCount(): Int {
        return myList.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.img5.setImageResource(myList[position].img5)
        holder.tvDate5.text = myList[position].tvDate5
        holder.tvShopName5.text = myList[position].tvShopName5

        holder.img5.setOnClickListener {
            val intent = Intent(context, MyHistoryDetail::class.java)
            intent.putExtra("imgId", myList[position].img5)
            intent.putExtra("tvDate5", myList[position].tvDate5)
            intent.putExtra("tvShopName5", myList[position].tvShopName5)

            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
        }

    }
}