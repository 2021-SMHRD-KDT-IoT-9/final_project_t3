package com.example.abproject

data class ShopVO (
    var imgShop : Int = 0,
    var shopName: String = "",
    var shopAddress : String = ""
)