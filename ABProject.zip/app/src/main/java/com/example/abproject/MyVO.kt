package com.example.abproject

data class MyVO (
    var img5 : Int = 0,
    var tvDate5 : String = "",
    var tvShopName5 : String = ""
)