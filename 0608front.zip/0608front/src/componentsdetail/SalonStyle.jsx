import React, {useState, useEffect } from "react";
import axios from 'axios';


const SalonStyle = () => {

  const [data, setData] = useState([]);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const response = await axios.get('http://59.0.234.211:8087/stylelist');
      setData(response.data);
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };


  return (
    <div className='salonstyle' style={{ overflow: 'auto' }}>
      <ul style={{ display: 'flex', flexDirection: 'row', flexWrap: 'wrap'}}>
        {data.map((hair) => (
          <li style={{ flex: '0 0 25%',padding:'7px', margin: '5px', backgroundColor:'aliceblue' }}>
            <div>
              <img src={`http://59.0.234.211:8087/hairStyle/${hair.hair_id}.jpg`} alt="Image" width="100" height="120" />
            </div>
          </li>
        ))}
      </ul>
    </div>
  )
}
export default SalonStyle