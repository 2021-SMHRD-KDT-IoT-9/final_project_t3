import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

const VideoPlay = () => {
  const [data, setData] = useState('');

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const response = await axios.get('http://59.0.234.211:8087/test'); // 백엔드의 엔드포인트 경로로 변경
      setData(response.data);
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };

  return (
    <div>
      <h1>VideoPlay</h1>
      <p>{data}</p>
    </div>
    



  );
};

export default VideoPlay;
