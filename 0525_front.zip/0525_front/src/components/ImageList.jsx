import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

const ImageList = () => {


  const [ckChange, setCkChange] = useState(true);
  const navigate = useNavigate()

  const handleRedirect = () => {
      setCkChange(false);
      navigate('/image-play');
    };


  return (
    <div>ImageList
      <br/>
    <button onClick={handleRedirect}>이미지 상세보기로 이동</button>
    </div>
  )
}

export default ImageList