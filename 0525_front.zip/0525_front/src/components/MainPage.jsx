import React from 'react'

const MainPage = () => {
    
    return (
        <div>
            <h1>MainPage</h1>
        </div>
    )
}

export default MainPage 